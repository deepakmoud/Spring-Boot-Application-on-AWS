package com.accenture.lkm.SpringDemoProject1;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller

@ResponseBody
public class SpringController {
	
	
	@RequestMapping(value="/hello", method = RequestMethod.GET)
	public String Firsthandler() {
		return "Hello It is my first program";
	}

}
