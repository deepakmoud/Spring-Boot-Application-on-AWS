package com.accenture.lkm.SpringDemoProject1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDemoProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDemoProject1Application.class, args);
	}

}
