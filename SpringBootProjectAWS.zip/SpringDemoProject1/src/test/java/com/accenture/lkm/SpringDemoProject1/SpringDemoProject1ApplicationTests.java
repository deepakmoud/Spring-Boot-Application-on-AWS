package com.accenture.lkm.SpringDemoProject1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
